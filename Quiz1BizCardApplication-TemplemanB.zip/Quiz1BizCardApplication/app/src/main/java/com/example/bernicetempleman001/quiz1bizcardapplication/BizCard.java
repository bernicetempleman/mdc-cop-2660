package com.example.bernicetempleman001.quiz1bizcardapplication;

/**
 * Created by Bernice.Templeman001 on 2/2/2015.
 */
public class BizCard {

    private int name;
    private int title;
    private int address1;
    private int address2;
    private int phone;


    public BizCard(int name, int title, int address1, int address2, int phone) {
        this.name = name;
        this.title = title;
        this.address1 = address1;
        this.address2 = address2;
        this.phone = phone;
    }

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public int getTitle() {
        return title;
    }

    public void setTitle(int title) {
        this.title = title;
    }

    public int getAddress1() {
        return address1;
    }

    public void setAddress1(int address1) {
        this.address1 = address1;
    }

    public int getAddress2() {
        return address2;
    }

    public void setAddress2(int address2) {
        this.address2 = address2;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }
}
