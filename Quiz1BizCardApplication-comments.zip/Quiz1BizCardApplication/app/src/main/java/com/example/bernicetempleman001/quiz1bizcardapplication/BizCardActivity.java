// Programmer : Bernice Templeman
// Class : Android 2660
// Quiz1: Business Card Application
//
/* Write a simple app that displays a business card..


The first line should be person's name (both first and last name).
The second line should include person's title.
The third line should include the address (number, street, and suite number if any).
The fourth line should include city, state (2 letter abbreviation), and postal code.
The fifth line should include the telephone number "(xxx)-xxx-xxxx"  You will need multiple TextViews.

Enter data for five (5) business cards.
The application needs to have "next" and "previous" button to move from card to card. (85%)
For full credit, replace the buttons with image buttons (<- and -> icons)  in the attached (images.zip) file. (100%)

*/
package com.example.bernicetempleman001.quiz1bizcardapplication;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;


public class BizCardActivity extends ActionBarActivity {

    private ImageButton mNextButton;
    private ImageButton mPreviousButton;
    private TextView mNameTextView;
    private TextView mTitleTextView;
    private TextView mAddress1TextView;
    private TextView mAddress2TextView;
    private TextView mPhoneTextView;

    private BizCard []mBizCardBank = new BizCard[]{

            //BizCard(int name, int title, int address1, int address2, int phone)
            new BizCard(R.string.bc1_name, R.string.bc1_title,  R.string.bc1_address1, R.string.bc1_address2, R.string.bc1_phone ),
            new BizCard(R.string.bc2_name, R.string.bc2_title,  R.string.bc2_address1, R.string.bc2_address2, R.string.bc2_phone ),
            new BizCard(R.string.bc3_name, R.string.bc3_title, R.string.bc3_address1, R.string.bc3_address2 ,R.string.bc3_phone ),
            new BizCard(R.string.bc4_name, R.string.bc4_title, R.string.bc4_address1, R.string.bc4_address2, R.string.bc4_phone ),
            new BizCard(R.string.bc5_name, R.string.bc5_title, R.string.bc5_address1, R.string.bc5_address2, R.string.bc5_phone ),
    };

    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biz_card);


    mNameTextView = (TextView)findViewById(R.id.name);
    int bizCard = mBizCardBank[mCurrentIndex].getName();
    mNameTextView.setText(bizCard);

    mTitleTextView = (TextView)findViewById(R.id.title);
    bizCard = mBizCardBank[mCurrentIndex].getTitle();
    mTitleTextView.setText(bizCard);

    mAddress1TextView = (TextView)findViewById(R.id.address1);
    bizCard = mBizCardBank[mCurrentIndex].getAddress1();
    mAddress1TextView.setText(bizCard);

    mAddress2TextView = (TextView)findViewById(R.id.address2);
    bizCard = mBizCardBank[mCurrentIndex].getAddress2();
    mAddress2TextView.setText(bizCard);

    mPhoneTextView = (TextView)findViewById(R.id.phone);
    bizCard = mBizCardBank[mCurrentIndex].getPhone();
    mPhoneTextView.setText(bizCard);


    mNextButton = (ImageButton)findViewById(R.id.next_button);
    mNextButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            mCurrentIndex = (mCurrentIndex + 1) % mBizCardBank.length;
            int bizCard = mBizCardBank[mCurrentIndex].getName();
            mNameTextView.setText(bizCard);

            bizCard = mBizCardBank[mCurrentIndex].getTitle();
            mTitleTextView.setText(bizCard);

            bizCard = mBizCardBank[mCurrentIndex].getAddress1();
            mAddress1TextView.setText(bizCard);

            bizCard = mBizCardBank[mCurrentIndex].getAddress2();
            mAddress2TextView.setText(bizCard);

            bizCard = mBizCardBank[mCurrentIndex].getPhone();
            mPhoneTextView.setText(bizCard);

        }
    });

    mPreviousButton = (ImageButton)findViewById(R.id.previous_button);
    mPreviousButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(mCurrentIndex > 0) {
                mCurrentIndex = (mCurrentIndex - 1) % mBizCardBank.length;
                int bizCard = mBizCardBank[mCurrentIndex].getName();
                mNameTextView.setText(bizCard);

                bizCard = mBizCardBank[mCurrentIndex].getTitle();
                mTitleTextView.setText(bizCard);

                bizCard = mBizCardBank[mCurrentIndex].getAddress1();
                mAddress1TextView.setText(bizCard);

                bizCard = mBizCardBank[mCurrentIndex].getAddress2();
                mAddress2TextView.setText(bizCard);

                bizCard = mBizCardBank[mCurrentIndex].getPhone();
                mPhoneTextView.setText(bizCard);


            }
        }
    });
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_biz_card, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
