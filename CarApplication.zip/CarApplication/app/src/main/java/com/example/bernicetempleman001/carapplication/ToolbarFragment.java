package com.example.bernicetempleman001.carapplication;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ToolbarFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ToolbarFragment extends Fragment {


    private static TextView textView;

    //private OnFragmentInteractionListener mListener;

    public ToolbarFragment() {
        // Required empty public constructor
    }

    ToolbarListener activityCallback;

    public interface ToolbarListener {
        public void onButtonClick(String text);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //TextView textView = new TextView(getActivity());
        //textView.setText(R.string.hello_blank_fragment);
        //return textView;

        View view = inflater.inflate(R.layout.toolbar_fragment, container, false);

       textView = (TextView)view.findViewById(R.id.textView1);

        final Button button = (Button)view.findViewById(R.id.button1);
        final Button button2 = (Button)view.findViewById(R.id.button2);
        final Button button3 = (Button)view.findViewById(R.id.button3);
        final Button button4 = (Button)view.findViewById(R.id.button4);


        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                buttonClicked(v);
            }
        });

        button2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                buttonClicked2(v);
            }
        });

        button3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                buttonClicked3(v);
            }
        });

        button4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                buttonClicked4(v);
            }
        });

        return view;

    }



    public void buttonClicked(View v){

        activityCallback.onButtonClick("my car info\nmpg\nhp\nmodel\n");
    }

    public void buttonClicked2(View v){

        activityCallback.onButtonClick("my car 2 info\nmpg\nhp\nmodel\n");
    }

    public void buttonClicked3(View v){

        activityCallback.onButtonClick("my car 3 info\nmpg\nhp\nmodel\n");
    }
    public void buttonClicked4(View v){

        activityCallback.onButtonClick("my car 4 info\nmpg\nhp\nmodel\n");
    }


    // TODO: Rename method, update argument and hook method into UI event
   /* public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }

    }
*/
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
         //   mListener = (OnFragmentInteractionListener) activity;
            activityCallback = (ToolbarListener)activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
       // mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}
