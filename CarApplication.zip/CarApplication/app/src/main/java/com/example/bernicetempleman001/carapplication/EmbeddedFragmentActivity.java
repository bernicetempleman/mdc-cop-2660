package com.example.bernicetempleman001.carapplication;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class EmbeddedFragmentActivity extends ActionBarActivity
        implements
        ToolbarFragment.ToolbarListener {

    ImageView image;
    private Button mViewPicButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_embedded_fragment);

      /*  mViewPicButton = (Button)findViewById(R.id.viewPicButton);
        mViewPicButton.setOnClickListener(new View.OnClickListener(){
            @Override
        public void onClick(View v){
                displayImage();
            }
        });
        */
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_embedded, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onButtonClick(String text) {
        TextFragment textFragment =
                (TextFragment)getFragmentManager().findFragmentById(R.id.text_fragment);
        textFragment.changeTextProperties(text);
    }

    public void displayImage(ImageView image){

        ImageFragment imageFragment =
                (ImageFragment)getFragmentManager().findFragmentById(R.id.image_fragment);
        image.setImageResource(R.drawable.arrow_right);
    }
}
