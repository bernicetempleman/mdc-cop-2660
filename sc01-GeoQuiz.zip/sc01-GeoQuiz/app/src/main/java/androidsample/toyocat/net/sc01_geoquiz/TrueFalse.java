package androidsample.toyocat.net.sc01_geoquiz;

/**
 * Created by Adnan on 1/25/2015.
 */
public class TrueFalse {
    private int question;
    private boolean trueQuestion;

    public TrueFalse(int mQuestion, boolean mTrueQuestion) {
        this.question = mQuestion;
        this.trueQuestion = mTrueQuestion;
    }

    public int getQuestion() {
        return question;
    }

    public void setQuestion(int question) {
        this.question = question;
    }

    public boolean isTrueQuestion() {
        return trueQuestion;
    }

    public void setTrueQuestion(boolean trueQuestion) {
        this.trueQuestion = trueQuestion;
    }
}
