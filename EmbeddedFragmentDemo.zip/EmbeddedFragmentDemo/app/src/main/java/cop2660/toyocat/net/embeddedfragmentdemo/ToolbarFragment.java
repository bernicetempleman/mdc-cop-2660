package cop2660.toyocat.net.embeddedfragmentdemo;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ToolbarFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class ToolbarFragment extends Fragment {

    //private OnFragmentInteractionListener mListener;
    private static EditText edittext;

    public ToolbarFragment() {
        // Required empty public constructor
    }

    ToolbarListener activityCallback;

    public interface ToolbarListener {
        public void onButtonClick(String text);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.toolbar_fragment, container, false);

        edittext = (EditText)view.findViewById(R.id.editText1);

        final Button button = (Button)view.findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                buttonClicked(v);
            }
        });
        return view;
    }

    public void buttonClicked(View v)
    {
        activityCallback.onButtonClick(edittext.getText().toString());
    }

    // TODO: Rename method, update argument and hook method into UI event
/* public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
*/
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            //mListener = (OnFragmentInteractionListener) activity;
            activityCallback = (ToolbarListener)activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}
